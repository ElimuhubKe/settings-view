I am a Readme!

*   [ ] I'm a not completed task
*   [x] I'm completed


![AbsoluteImage](https://example.com/static/image.jpg)
![RelativeImage](static/image.jpg)
![Base64Image](data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==)

<script>alert('oh, hai');</script>
<iframe src="https://atom.io"></iframe>
